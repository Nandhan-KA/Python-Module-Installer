from .installer import installer, run, install_basic_modules, install_advanced_modules, install_build_modules, install_computervision_modules, install_deeplearning_modules, install_fullstack_modules, install_jupyter_modules, install_machinelearning_modules, install_network_modules, install_science_modules
__version__ = "2.1.1"
